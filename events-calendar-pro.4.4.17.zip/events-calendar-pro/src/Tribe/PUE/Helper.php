<?php

class Tribe__Events__Pro__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = '57a8fee3b3ae715848451413fac7f165702a3be7';

}
