<?php
_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Mini_Calendar_Shortcode' );

class Tribe__Events__Pro__Mini_Calendar_Shortcode extends Tribe__Events__Pro__Shortcodes__Mini_Calendar {}
