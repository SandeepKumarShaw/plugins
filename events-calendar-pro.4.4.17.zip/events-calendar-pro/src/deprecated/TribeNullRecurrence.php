<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Null_Recurrence' );


	class TribeNullRecurrence extends Tribe__Events__Pro__Null_Recurrence {

	}