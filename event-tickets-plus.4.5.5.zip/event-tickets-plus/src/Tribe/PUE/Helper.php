<?php

class Tribe__Tickets_Plus__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = 'b2a876bf54a89a6ffef9d90853ca66639f09cfed';

}
