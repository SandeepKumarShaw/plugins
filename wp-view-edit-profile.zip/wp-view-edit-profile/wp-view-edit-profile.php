<?php
/*
* Plugin Name: WP View-Edit Profile
* Description: Using this wordpress plugin user can view and edit their profile from frontend
* Author Name: WS WP Team
*/

// to include files
include( plugin_dir_path( __FILE__ ) . 'view-my-profile.php');
include( plugin_dir_path( __FILE__ ) . 'edit-my-profile.php');
?>