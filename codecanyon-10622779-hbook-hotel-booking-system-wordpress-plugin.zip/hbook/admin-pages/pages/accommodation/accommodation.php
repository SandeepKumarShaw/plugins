<?php
class HbAdminPageAccommodation extends HbAdminPage {
    
    public function __construct( $page_id, $hbdb, $utils, $options_utils ) {
        $this->data = array(
            'hb_text' => array()
        );
		parent::__construct( $page_id, $hbdb, $utils, $options_utils );
	}
	
	public function display() {}
    
}