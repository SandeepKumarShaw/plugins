=== Frontend custom registration and login form ===

[register_form regtype="job_seeker/job_provider"] short code to display registration form

[login_form] short code to display login form

[get_related_listing] View conected/related user list
